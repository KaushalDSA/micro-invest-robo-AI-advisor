package com.robo_investor_platform.Advisor_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvisorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
