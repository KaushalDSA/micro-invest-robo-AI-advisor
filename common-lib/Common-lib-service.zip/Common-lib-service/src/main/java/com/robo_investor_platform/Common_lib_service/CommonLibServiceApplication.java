package com.robo_investor_platform.Common_lib_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonLibServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonLibServiceApplication.class, args);
	}

}
