package com.robo_investor_platform.Common_lib_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommonLibServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
