package com.robo_investor_platform.Investment_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvestmentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
